package com.example.location_vinove

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
