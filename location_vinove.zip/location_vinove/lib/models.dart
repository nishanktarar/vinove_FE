class Member {
  final int id;
  final String name;
  final double currentLat;
  final double currentLng;
  final List<VisitedLocation> visitedLocations;

  Member({
    required this.id,
    required this.name,
    required this.currentLat,
    required this.currentLng,
    required this.visitedLocations,
  });

  factory Member.fromJson(Map<String, dynamic> json) {
    return Member(
      id: json['id'],
      name: json['name'],
      currentLat: json['currentLat'],
      currentLng: json['currentLng'],
      visitedLocations: (json['visitedLocations'] as List)
          .map((i) => VisitedLocation.fromJson(i))
          .toList(),
    );
  }
}

class VisitedLocation {
  final double lat;
  final double lng;
  final DateTime time;

  VisitedLocation({required this.lat, required this.lng, required this.time});

  factory VisitedLocation.fromJson(Map<String, dynamic> json) {
    return VisitedLocation(
      lat: json['lat'],
      lng: json['lng'],
      time: DateTime.parse(json['time']),
    );
  }
}
