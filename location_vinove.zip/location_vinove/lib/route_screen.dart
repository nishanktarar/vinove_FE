import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'models.dart';

class RouteScreen extends StatelessWidget {
  final Member member;
  final VisitedLocation startLocation;
  final VisitedLocation stopLocation;

  RouteScreen({
    required this.member,
    required this.startLocation,
    required this.stopLocation,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Route Details')),
      body: Column(
        children: [
          ListTile(
            title: Text('Start Location: ${startLocation.lat}, ${startLocation.lng}'),
            subtitle: Text('Stop Location: ${stopLocation.lat}, ${stopLocation.lng}'),
          ),
          ListTile(
            title: Text('Total KMs: ${_calculateDistance(startLocation, stopLocation)}'),
            subtitle: Text('Total Duration: ${_calculateDuration(startLocation.time, stopLocation.time)}'),
          ),
          Expanded(
            child: GoogleMap(
              initialCameraPosition: CameraPosition(
                target: LatLng(startLocation.lat, startLocation.lng),
                zoom: 14,
              ),
              polylines: Set<Polyline>.of(_createPolylines()),
              markers: Set<Marker>.of(_createMarkers()),
            ),
          ),
        ],
      ),
    );
  }

  double _calculateDistance(VisitedLocation start, VisitedLocation stop) {
    // Custom logic to calculate distance between start and stop locations
  }

  String _calculateDuration(DateTime start, DateTime stop) {
    // Custom logic to calculate duration between start and stop times
  }

  List<Polyline> _createPolylines() {
    return [
      Polyline(
        polylineId: PolylineId('route'),
        points: member.visitedLocations.map((loc) => LatLng(loc.lat, loc.lng)).toList(),
        color: Colors.blue,
      ),
    ];
  }

  List<Marker> _createMarkers() {
    return member.visitedLocations.map((loc) {
      return Marker(
        markerId: MarkerId(loc.time.toIso8601String()),
        position: LatLng(loc.lat, loc.lng),
        icon: loc.time.difference(DateTime.now()).inMinutes > 10
            ? BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed)
            : BitmapDescriptor.defaultMarker,
      );
    }).toList();
  }
}
