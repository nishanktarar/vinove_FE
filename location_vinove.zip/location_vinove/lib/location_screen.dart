import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:timeline_tile/timeline_tile.dart';
import 'services.dart'; // Import the services
import 'models.dart';

class LocationScreen extends StatefulWidget {
  final Member member;

  LocationScreen({required this.member});

  @override
  _LocationScreenState createState() => _LocationScreenState();
}

class _LocationScreenState extends State<LocationScreen> {
  late ApiService apiService;
  late Future<List<VisitedLocation>> futureLocations;

  @override
  void initState() {
    super.initState();
    apiService = ApiService('http://your_backend_url'); // Modify this to your backend URL
    futureLocations = apiService.fetchMemberLocations(widget.member.id);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Location & Route')),
      body: Column(
        children: [
          Expanded(
            child: GoogleMap(
              initialCameraPosition: CameraPosition(
                target: LatLng(widget.member.currentLat, widget.member.currentLng),
                zoom: 14,
              ),
              markers: Set<Marker>.of(_createMarkers()),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<VisitedLocation>>(
              future: futureLocations,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                } else {
                  final locations = snapshot.data ?? [];
                  return ListView.builder(
                    itemCount: locations.length,
                    itemBuilder: (context, index) {
                      return TimelineTile(
                        alignment: TimelineAlign.start,
                        endChild: Container(
                          padding: EdgeInsets.all(8),
                          child: Text('Visited at ${locations[index].time}'),
                        ),
                        isFirst: index == 0,
                        isLast: index == locations.length - 1,
                      );
                    },
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  List<Marker> _createMarkers() {
    return widget.member.visitedLocations.map((loc) {
      return Marker(
        markerId: MarkerId(loc.time.toIso8601String()),
        position: LatLng(loc.lat, loc.lng),
      );
    }).toList();
  }
}
