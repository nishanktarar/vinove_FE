import 'dart:convert';
import 'package:http/http.dart' as http;
import 'models.dart';

class ApiService {
  final String baseUrl;
  //backend url
  ApiService(this.baseUrl);

  Future<List<Member>> fetchMembers() async {
    final response = await http.get(Uri.parse('$baseUrl/members'));

    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse.map((member) => Member.fromJson(member)).toList();
    } else {
      throw Exception('Failed to load members');
    }
  }
}
